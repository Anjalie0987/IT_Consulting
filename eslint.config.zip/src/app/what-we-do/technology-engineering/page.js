"use client";

import TechnologyEngineering from "../../../components/TechnologyEngineering";

export default function Page() {
    return (
        <main className="min-h-screen">
            <TechnologyEngineering />
        </main>
    );
}
