"use client";

import StrategyConsulting from "../../../components/StrategyConsulting";

export default function Page() {
    return <StrategyConsulting />;
}
